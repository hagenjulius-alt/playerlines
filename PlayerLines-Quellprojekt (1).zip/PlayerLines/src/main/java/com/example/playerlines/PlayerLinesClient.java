package com.example.playerlines;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

public class PlayerLinesClient implements ClientModInitializer {
    private static boolean enabled = true;
    private static KeyMapping toggleKey;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.playerlines.toggle", GLFW.GLFW_KEY_K,
                KeyMapping.Category.MISC));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.consumeClick()) enabled = !enabled;
        });
        WorldRenderEvents.AFTER_ENTITIES.register(context -> render(context));
    }

    private static void render(net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext context) {
        Minecraft client = Minecraft.getInstance();
        if (!enabled || client.level == null || client.player == null || client.options.hideGui) return;
        Vec3 camera = context.camera().getPosition();
        Vec3 start = client.player.getEyePosition();
        MultiBufferSource.BufferSource buffers = client.renderBuffers().bufferSource();
        var matrices = context.matrixStack();
        if (matrices == null) return;
        matrices.pushPose();
        matrices.translate(-camera.x, -camera.y, -camera.z);
        for (Player target : client.level.players()) {
            if (target == client.player || target.isRemoved() || !target.isAlive()) continue;
            if (client.player.distanceTo(target) > 100.0f) continue;
            Vec3 torso = target.position().add(0.0, target.getBbHeight() * 0.55, 0.0);
            // Lines are rendered with the vanilla line layer; depth testing is disabled by the event's render pass.
            LevelRenderer.renderLine(matrices, buffers.getBuffer(RenderType.lines()), start, torso, 0.2f, 0.85f, 1.0f, 1.0f);
            Vec3 head = target.position().add(0.0, target.getBbHeight() + 0.35, 0.0);
            Component name = target.getName();
            EntityRenderDispatcher dispatcher = client.getEntityRenderDispatcher();
            matrices.pushPose();
            matrices.translate(head.x, head.y, head.z);
            matrices.mulPose(dispatcher.cameraOrientation());
            matrices.scale(-0.025f, -0.025f, 0.025f);
            var font = client.font;
            float x = -font.width(name) / 2.0f;
            font.drawInBatch(name, x, 0, 0xFFFFFFFF, false, matrices.last().pose(), buffers,
                    net.minecraft.client.gui.Font.DisplayMode.SEE_THROUGH, 0x55000000, 0xF000F0);
            matrices.popPose();
        }
        matrices.popPose();
        buffers.endBatch();
    }
}
